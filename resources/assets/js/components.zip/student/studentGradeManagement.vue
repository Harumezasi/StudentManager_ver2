<template>
<div class="studnetGradeManagement">

  <!-- Header -->
  <v-parallax class="mainImage" src="/images/studentGrade2.jpg" height="300">
    <h1 class="categoryGrade">Grade Management</h1>
  </v-parallax>

  <div class = "studentPageTopDiv">
    <v-flex xs12>
      <v-container grid-list-xl>
        <v-layout row wrap align-center>

          <!-- 강의 목록 영역 -->
          <v-flex xs12 md5>
            <v-card class = "lectureListCard">
              <v-card-text style="position:relative; bottom:15px;">
                <v-flex xs12>
                  <v-layout row wrap align-center>
                    <v-flex xs12 md2>
                      <v-icon color = "light-green darken-2" large>format_list_bulleted</v-icon>
                    </v-flex>
                    <v-flex xs12 md4>
                      <h2>講義リスト</h2>
                    </v-flex>
                    <v-flex xs12 md6>
                      <v-select :items="semester" v-model="e1" label="Select" color = "light-green darken-2" single-line></v-select>
                    </v-flex>
                  </v-layout>
                </v-flex>
              </v-card-text>

              <!-- 강의 목록 list-->
              <v-list two-line>
                <div class = "lectureListScroll">

                  <v-subheader>
                    2018년 2학기
                  </v-subheader>

                  <template v-for="datas in gradeData">

                    <v-divider></v-divider>

                    <v-list-tile
                      :key="datas"
                      avatar
                      @click=""
                      style="margin: 20px 0 20px 0"
                    >
                      <v-list-tile-content>
                        <v-list-tile-title v-html="datas.name"></v-list-tile-title>
                        <v-list-tile-sub-title v-html="datas.porf_name"></v-list-tile-sub-title>
                      </v-list-tile-content>
                    </v-list-tile>
                  </template>
                </div>
             </v-list>

            </v-card>
          </v-flex>



          <!-- 해당 강의 성적 정보 영역 -->
          <v-flex xs12 md7>
            <v-card class = "gradeCheckCard">

              <v-card-text>
                <v-flex xs12>
                  <v-layout row wrap align-center>
                    <v-flex xs12 md1>
                      <v-icon color = "light-green darken-2" large>bubble_chart</v-icon>
                    </v-flex>
                    <!-- 해당 강의명 -->
                    <v-flex xs12 md7>
                      <h2>실무 일본어 회화(2)</h2>
                    </v-flex>
                  </v-layout>
                </v-flex>
              </v-card-text>

              <!-- 강의 정보 -->
              <v-flex xs12>
                <v-container>
                  <v-layout row wrap align-center>

                    <!-- 교수님 정보 -->
                    <v-flex xs12 md3>
                      <v-avatar class = "elevation-5" size = "120px">
                        <img src="/images/professorSample.jpg">
                      </v-avatar>
                      <div class="headline" style="margin:25px 0 0 0">서희경 <span style="font-weight:lighter;font-size:18px;">교수</span></div>
                    </v-flex>

                    <!-- 성적 간단 테이블 -->
                    <v-flex xs12 md9>
                      <table class="type03">
                        <thead>
                         <tr>
                           <th scope="cols">분류</th>
                           <th scope="cols">횟수</th>
                           <th scope="cols">총점</th>
                           <th scope="cols">득점</th>
                           <th scope="cols">평균</th>
                         </tr>
                        </thead>
                        <tbody>
                          <tr>
                              <th scope="row">중간</th>
                              <td>2</td>
                              <td>318</td>
                              <td>100</td>
                              <td>50</td>
                          </tr>
                          <tr>
                              <th scope="row">기말</th>
                              <td>2</td>
                              <td>318</td>
                              <td>100</td>
                              <td>50</td>
                          </tr>
                          <tr>
                              <th scope="row">쪽지</th>
                              <td>2</td>
                              <td>318</td>
                              <td>100</td>
                              <td>50</td>
                          </tr>
                          <tr>
                              <th scope="row">과제</th>
                              <td>2</td>
                              <td>318</td>
                              <td>100</td>
                              <td>50</td>
                          </tr>
                        </tbody>
                      </table>
                    </v-flex>
                  </v-layout>
                </v-container>
              </v-flex>

              <!-- 상세 성적 조회 -->
              <v-flex xs12>
                <v-container>
                  <v-layout row wrap align-center>
                    <v-card-text>
                      <div
                      style="font-size:23px;
                             border-bottom: 2px solid;
                             border-color: rgb(80, 154, 56);"
                      >상세 성적 조회</div>
                    </v-card-text>
                    <v-data-table
                      :headers="detailTableHeaders"
                      :items="tests"
                      :search="search"
                      :pagination.sync="pagination"
                      hide-actions
                      class="elevation-0"
                      style="position: relative;left:15px;"
                    >
                      <template slot="headerCell" slot-scope="props">
                        <v-tooltip bottom>
                          <span slot="activator">
                            {{ props.header.text }}
                          </span>
                          <span>
                            {{ props.header.text }}
                          </span>
                        </v-tooltip>
                      </template>
                      <template slot="items" slot-scope="props">
                        <td class="text-xs-center">{{ props.item.date }}</td>
                        <td class="text-xs-center">{{ props.item.detailType }}</td>
                        <td class="text-xs-center">{{ props.item.myScore }}</td>
                        <td class="text-xs-center">{{ props.item.totalScore }}</td>
                        <td class="text-xs-center">{{ props.item.testType }}</td>
                      </template>
                    </v-data-table>
                    <div class="text-xs-center pt-3" style="margin:auto; padding:auto">
                      <v-pagination v-model="pagination.page" :length="pages" color="light-green darken-2" circle></v-pagination>
                    </div>
                  </v-layout>
                </v-container>
              </v-flex>
            </v-card>
          </v-flex>

        </v-layout>
      </v-container>
    </v-flex>
  </div>


</div>
</template>

<script>
export default {
  data() {
    return {
      selected: [],
      pagination: {},
      e1: null,
      /* 학기 선택 */
      semester: [{
          text: '2016년 1학기'
        },
        {
          text: '2016년 2학기'
        }
      ],
      /* 강의 목록 */
      lectures: [
         { header: '2018년 1학기' },
         { divider: true, inset: true },
         {
           lectureName: '실무 일본어 회화(2)',
           lectureProfessor: '서희경 교수님'
         },
         { divider: true, inset: true },
         {
           lectureName: '실무 일본어 회화(2)',
           lectureProfessor: '서희경 교수님'
         },
         { divider: true, inset: true }
       ],
       /* 상세 성적 정보 */
       detailTableHeaders: [
          { text: '날짜', value: 'date' },
          { text: '시험 이름', value: 'detailType' },
          { text: '득점', value: 'myScore' },
          { text: '만점', value: 'totalScore' },
          { text: '분류', value: 'testType' }
        ],
        tests: [
          {
            date: '2018-05-10',
            detailType: '2018년 1학기 중간고사',
            myScore: 30,
            totalScore: 100,
            testType: '중간'
          },
          {
            date: '2018-05-10',
            detailType: '2018년 1학기 중간고사',
            myScore: 30,
            totalScore: 100,
            testType: '중간'
          }
        ]
    }
  },
  mounted(){
    this.getData();
  },
  methods: {
    getData(){
      axios.get('/student/subject')
      .then((response)=>{
        /* 년도, 학기 */
        // this.days.this = response.data.message.pagination.this;
        this.dayData = response.data.message.pagination['this']

        /* 과목 */
        this.gradeData = response.data.message.subjects;
        console.log(response.data);
      }).catch((error) => {
        alert('講義の情報がありません。')
      })
    }
  },
  /* 페이지네이션 */
  computed: {
     pages () {
       if (this.pagination.rowsPerPage == null ||
         this.pagination.totalItems == null
       ) return 0

       return Math.ceil(this.pagination.totalItems / this.pagination.rowsPerPage)
     }
   }
}
</script>

<style>

/* Header */
.categoryGrade {
  color: #FFFFFF;
  font-size: 38px;
  position: relative;
  font-family: "Montserrat";
  font-weight: Bold;
  position: relative;
  left: 48px;
  bottom: 50px;
}

/* scroll 관련 */
.lectureListScroll {
  overflow-y: scroll;
  height: 630px;
}

/* 강의 */
.lectureListCard {
  border-radius: 0.6975rem;
  position: relative;
  bottom: 200px;
  min-height: 845px;
  box-shadow:  0px 4px 10px 0 rgba(33, 33, 33, 0.36);
}

/* 해당 강의 성적 확인 */
.gradeCheckCard {
  border-radius: 0.6975rem;
  position: relative;
  bottom: 200px;
  min-height: 680px;
  box-shadow:  0px 4px 10px 0 rgba(33, 33, 33, 0.36);
}

/*-- 테이블 --*/
table.type03 {
    border-collapse: collapse;
    text-align: center;
    line-height: 1.5;
    border-top: 1px solid #ffffff;
    border-left: 3px solid #3ba204;
    margin : 20px 10px;
}
table.type03 th {
    width: 147px;
    padding: 9px;
    font-weight: bold;
    vertical-align: top;
    color: #525252;
    border-right: 1px solid #ffffff;
    border-bottom: 1px solid #c7c7c7;

}
table.type03 td {
    width: 349px;
    padding: 10px;
    color: #4e872b;
    font-style: italic;
    vertical-align: top;
    border-right: 1px solid #ffffff;
    border-bottom: 1px solid #ccc;
}

/* 스크롤 */
/* width */
::-webkit-scrollbar {
    width: 9px;
}

/* Track */
::-webkit-scrollbar-track {
    background-color: rgb(208, 208, 208);
    border-radius: 10px;
}

/* Handle */
::-webkit-scrollbar-thumb {
    background: rgb(195, 195, 195);
    border-radius: 10px;
}

/* Handle on hover */
::-webkit-scrollbar-thumb:hover {
    background: rgb(190, 190, 190);
}

</style>
