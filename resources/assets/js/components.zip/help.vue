<template>
  <div>
    help Test page
    <br>

    <form action="/sendTest" method="get">
      학번 : <input type="text" name="std_id" maxlength="7"></input>
      <input type="submit" value="재발급"></input>
    </form>

  </div>
</template>

<script>
    export default {
        data () {
            return {

            }
        },
        mounted() {

        },
        methods: {

        }
    }
</script>

<style>

</style>
